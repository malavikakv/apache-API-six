const express = require('express');
const app = express();
const swaggerUi = require('swagger-ui-express')
 swaggerDocument = require('./swagger.json');
 const bodyParser = require('body-parser');
 const axios = require('axios');

 
// Middleware to parse JSON data
app.use(express.json());
app.use(express.urlencoded({extended:true}))

 // Route to obtain the access token
 app.post('/Access_Token', async (req, res) => {

  const client_id= req.body.client_id
  const client_secret= req.body.client_secret
  const username= req.body.username
  const password= req.body.password
  
 console.log(username,password)
 // Define the URL where you want to obtain the access token
 const tokenUrl = 'http://localhost:8080/auth/realms/iplon_realm/protocol/openid-connect/token'
 const data = new URLSearchParams({
  client_id: client_id,
  username: username,
  password: password,
  grant_type: 'password',
  client_secret: client_secret,
});

const config = {
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
};

const url = 'http://localhost:8080/auth/realms/iplon_realm/protocol/openid-connect/token';

axios.post(url, data, config)
  .then((response) => {
    res.send(response.data)
    console.log('Access Token:', response.data.access_token);
  })
  .catch((error) => {
    console.error('Error:', error.data);
  })
});

  // Start the server
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
  // Start the server
  app.listen(8600, () => {
    console.log('Server started on port 8600');
  })
