const express = require('express');
const app = express();
const swaggerDocument = require('./test.json');
const swaggerUi = require('swagger-ui-express');


// Serve the Swagger UI at the /api-docs endpoint
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Define a sample route that returns "Hello World"
app.get('/hello', (req, res) => {
  res.send('Hello World');
});

// Start the Express server
const PORT = process.env.PORT || 5500;
app.listen(PORT, () => {
  console.log(`test api Server is running on port ${PORT}`);
});
