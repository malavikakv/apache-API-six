const express = require('express');
const swaggerDocument = require('./swagger.json');
const swaggerUi = require('swagger-ui-express');
const { InfluxDB, Point } = require('@influxdata/influxdb-client');
const { Client } = require('pg');
const fs = require('fs');

const app = express();


const pool = new Client({
	user: 'postgres',
	host: 'localhost',
	database: 'api',
	password: 'iplon321',
	port: 5432, // or your PostgreSQL server's port number
  });
  pool.connect((err) => {
	if (err) {
	  console.error('connection error', err.stack);
	} else {
	  console.log('connected to postgres');
	}
  });

// Protected API endpoint with JWT authentication
app.get('/influx', async (req, res) => {
    var array=[]
    var result=[]
    var org_id =req.query.org
    var p=req.query.p
    var iid=req.query.id
    var d=req.query.d
    var f=req.query.f
    var ZoneInfo=parseInt(req.query.ZoneInfo)
    
   
  var influx = new InfluxDB({
        url:'https://influx-america.iplon.co.in', 
        token:'0kYQ-vIPbUrHR7QbFLSQf-WcGWpLkEe_0gU8gTB-cfnQvV74jxmDkqiHeePYEJ72Oa5tLZ69CCqQExHtIA-4kA=='
    })
    var org = 'microgridlakeamerica'
    var start_limit=req.query.Start_Limit
    if (!start_limit) {
        var start=req.query.start
        if (start) {
            var start=req.query.start
            const start_timestamp = new Date(start);
            const start_timestamp1 = start_timestamp.getTime();
            var StartTime1 = new Date((start_timestamp1-ZoneInfo)).toISOString().slice(0, 19);
            var StartTime = StartTime1 + 'Z';
        }

        var stop=req.query.stop
        if (stop) {	
            const stop_timestamp = new Date(stop);
            const stop_timestamp1 = stop_timestamp.getTime();
            var StopTime1 = new Date((stop_timestamp1-ZoneInfo)).toISOString().slice(0, 19);
            var StopTime = StopTime1 + 'Z';
            console.log("stop time is update");
        }
    }
    const queryApi = influx.getQueryApi(org)

    if (start_limit) {
      var fluxQuery = `from(bucket:"egaugemeters") |> range(start: ${start_limit}) |> filter(fn: (r) => r["_measurement"] == "report")|> filter(fn: (r) => r["p"] == "${p}")|> filter(fn: (r) => r["iid"] == "${iid}")|> filter(fn: (r) => r["d"] == "${d}")|> filter(fn: (r) => r["f"] == "${f}")|> filter(fn: (r) => r["_field"] == "value")  |> yield(name: "last")`;
    } else if (f == "EAE_DAY") {
      fluxQuery = `from(bucket:"egaugemeters") |> range(start: ${StartTime}, stop: ${StopTime}) |> filter(fn: (r) => r["_measurement"] == "report")|> filter(fn: (r) => r["p"] == "${p}")|> filter(fn: (r) => r["iid"] == "${iid}")|> filter(fn: (r) => r["d"] == "${d}")|> filter(fn: (r) => r["f"] == "${f}")|> filter(fn: (r) => r["_field"] == "value")   |> aggregateWindow(every: 24h, offset:480m, fn: last, createEmpty: true)`;
    } else if (f == "EAE_Month") {
      fluxQuery = `from(bucket:"egaugemeters") |> range(start: ${StartTime}, stop: ${StopTime}) |> filter(fn: (r) => r["_measurement"] == "report")|> filter(fn: (r) => r["p"] == "${p}")|> filter(fn: (r) => r["iid"] == "${iid}")|> filter(fn: (r) => r["d"] == "${d}")|> filter(fn: (r) => r["f"] == "${f}")|> filter(fn: (r) => r["_field"] == "value")   |> aggregateWindow(every: 1mo, offset:60m, fn: last, createEmpty: true)`;
    } else {
      fluxQuery = `from(bucket:"egaugemeters") |> range(start: ${StartTime}, stop: ${StopTime}) |> filter(fn: (r) => r["_measurement"] == "report")|> filter(fn: (r) => r["p"] == "${p}")|> filter(fn: (r) => r["iid"] == "${iid}")|> filter(fn: (r) => r["d"] == "${d}")|> filter(fn: (r) => r["f"] == "${f}")|> filter(fn: (r) => r["_field"] == "value") |> yield(name: "last")`;
    }
  
    console.log(new Date(),fluxQuery);

    queryApi.queryRows(fluxQuery,{ next(row, tableMeta) {
       var  o = tableMeta.toObject(row);
        const date = new Date(o._time);
        const timestamp = date.getTime();
        var s = new Date(timestamp + ZoneInfo).toISOString();
        //array.push(Array(`time:${s},id:${o.iid},b:${o.b},d:${o.d},f:${o.f},value:${o._value}`))

        array.push(Array(s,o._value))

    },
    error(error) {
        console.log('QUERY FAILED', error)
    },
    complete: () => {
        const final = {
            name: "report",
            tags: { f: f },
            columns: ["time", "round"],
            values: array
        };
        result.push(final);
        res.send(result);
        console.log('QUERY SUCCESS');
    }
 })
});


// Serve the Swagger UI at the /api-docs endpoint
app.use('/api-ui', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Start the server
app.listen(6500, () => {
  console.log('influx service started on port 6500');
});