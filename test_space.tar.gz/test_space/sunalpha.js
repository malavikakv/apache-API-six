const express = require('express');
const app = express();
const swaggerUi = require('swagger-ui-express')
 swaggerDocument = require('./swagger.json');
 const { InfluxDB, Point } = require('@influxdata/influxdb-client');
 const { Client } = require('pg');
 const bodyParser = require('body-parser');
 const axios = require('axios');

// Middleware to parse JSON data
app.use(express.json());
app.use(express.urlencoded({extended:true}))


// Serve static files from the "public" directory

const pool = new Client({
	user: 'postgres',
	host: 'localhost',
	database: 'iplon',
	password: 'iplon321',
	port: 5432, // or your PostgreSQL server's port number
  });
  pool.connect((err) => {
	if (err) {
	  console.error('connection error', err.stack);
	} else {
	  console.log('connected to GCP postgres');
	}
  });

// Protected API endpoint
app.get('/sunalpha', async(req, res) => {
	var array=[]
	  var result=[]
	  var org_id =req.query.org
	  var iid=req.query.id
	  var d=req.query.d
	  var f=req.query.f
	  var b=req.query.b
	  var bd=req.query.bd
	var ZoneInfo=parseInt(req.query.ZoneInfo)
		var start=req.query.start
	var stop=req.query.stop 
	pool.query(`SELECT * FROM influx WHERE ORG_ID = $1`,[org_id], (error, results) => {

		if (error) {
			console.error(error);
			return;
		}
	

		var org_url=results.rows[0].url;
		var org_token=results.rows[0].token;
		var org_name=results.rows[0].org;
		var org_measurement = results.rows[0].measurement;
		var org_bucket = results.rows[0].bucket;
  
		// Call the function and pass the values
		processDbCredentials(org_measurement,org_bucket,org_url,org_token,org_name);
	  });
	
	  function processDbCredentials(org_measurement,org_bucket,org_url,org_token,org_name) {
	  console.log("info fetched from table")
	
	  { var influx = new InfluxDB({
		  url:org_url, 
		  token:org_token
	  })
	  var org = org_name
	  var start_limit=req.query.Start_Limit
  if (!start_limit) {
		  if (start) {
			const start_timestamp = new Date(start);
			const start_timestamp1 = start_timestamp.getTime();
			var StartTime1 = new Date((start_timestamp1 - ZoneInfo)).toISOString().slice(0, 19);
			var StartTime = StartTime1 + 'Z';
			console.log("starttime --- ",StartTime);
		}
		  console.log(stop)
		  if (stop) {	
			console.log("stop",stop)
			  const stop_timestamp = new Date(stop)
			  const stop_timestamp1 = stop_timestamp.getTime();
			  var StopTime1 = new Date((stop_timestamp1-ZoneInfo)).toISOString().slice(0, 19);
			  var StopTime = StopTime1 + 'Z';
			  console.log("stop time is update",StopTime);
		  }

	  }
	  const queryApi = influx.getQueryApi(org)

	  if (start_limit) {
		fluxQuery = `from(bucket:"${org_bucket}") |> range(start: ${start_limit}) |> filter(fn: (r) => r["_measurement"] == "${org_measurement}")|> filter(fn: (r) => r["iid"] == "${iid}")|> filter(fn: (r) => r["bd"] == "${bd}")|> filter(fn: (r) => r["b"] == "${b}")|> filter(fn: (r) => r["d"] == "${d}")|> filter(fn: (r) => r["f"] == "${f}")|> filter(fn: (r) => r["_field"] == "value")  |> yield(name: "last")`;
	  } else {
	fluxQuery = `from(bucket:"${org_bucket}")  |> range(start: ${StartTime}, stop: ${StopTime}) |> filter(fn: (r) => r["_measurement"] == "${org_measurement}")|> filter(fn: (r) => r["iid"] == "${iid}")|> filter(fn: (r) => r["bd"] == "${bd}")|> filter(fn: (r) => r["b"] == "${b}")|> filter(fn: (r) => r["d"] == "${d}")|> filter(fn: (r) => r["f"] == "${f}")|> filter(fn: (r) => r["_field"] == "value")  |> yield(name: "last")`;
	  }
	
	  console.log(new Date(),fluxQuery);
  
	  queryApi.queryRows(fluxQuery,{ next(row, tableMeta) {
		  o = tableMeta.toObject(row);
		  const date = new Date(o._time);
		  const timestamp = date.getTime();
		  var s = new Date(timestamp + ZoneInfo).toISOString();
		  //array.push(Array(`time:${s},id:${o.iid},b:${o.b},d:${o.d},f:${o.f},value:${o._value}`))
  
		  array.push(Array(s,o._value))
  
	  },
	  error(error) {
		  console.log('QUERY FAILED', error)
	  },
	  complete: () => {
		  const final = {
			  name: org_measurement,
			  tags: { f: f },
			  columns: ["time", "round"],
			  values: array
		  };
		  result.push(final);
		  res.send(result);
		  console.log('QUERY SUCCESS');
	  }
   })
  }
	  
  }});

// Route to obtain the access token
 app.post('/Access_Token', async (req, res) => {

  const client_id= req.body.client_id
  const client_secret= req.body.client_secret
  const username= req.body.username
  const password= req.body.password

 console.log(username,password)
 // Define the URL where you want to obtain the access token
 const tokenUrl = 'http://localhost:8080/auth/realms/iplon_realm/protocol/openid-connect/token'
 const data = new URLSearchParams({
  client_id: client_id,
  username: username,
  password: password,
  grant_type: 'password',
  client_secret: client_secret,
});

const config = {
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
};

const url = 'http://localhost:8080/auth/realms/iplon_realm/protocol/openid-connect/token';

axios.post(url, data, config)
  .then((response) => {
    res.send(response.data)
    console.log('Access Token:', response.data.access_token);
  })
  .catch((error) => {
    console.error('Error:', error.data);
  })
});
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
// Start the server
app.listen(8800, () => {
  console.log('Server started on port 8800');
});

