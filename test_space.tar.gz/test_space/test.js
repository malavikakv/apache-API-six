const express = require('express');
const app = express();
const swaggerUi = require('swagger-ui-express')
 swaggerDocument = require('./swagger.json');
 const { InfluxDB, Point } = require('@influxdata/influxdb-client');
 const { Client } = require('pg');

// Serve static files from the "public" directory

const pool = new Client({
	user: 'postgres',
	host: 'localhost',
	database: 'iplon',
	password: 'iplon321',
	port: 5432, // or your PostgreSQL server's port number
  });
  pool.connect((err) => {
	if (err) {
	  console.error('connection error', err.stack);
	} else {
	  console.log('connected to GCP postgres');
	}
  });

// Protected API endpoint
app.get('/sunalpha', async(req, res) => {
	var array=[]
	  var result=[]
	  var org_id =req.query.org
	  var p=req.query.p
	  var iid=req.query.id
	  var d=req.query.d
	  var f=req.query.f
	  var b=req.query.b
	  var bd=req.query.bd
	var ZoneInfo=parseInt(req.query.ZoneInfo)
	  pool.query(`SELECT * FROM influx WHERE ORG_ID = $1`,[org_id], (error, results) => {

		if (error) {
			console.error(error);
			return;
		}
		var org_username = results.rows[0].username;
		var org_password = results.rows[0].password;
		var org_url=results.rows[0].url;
		var org_token=results.rows[0].token;
		var org_name=results.rows[0].org;
		var org_measurement = results.rows[0].measurement;
		var org_bucket = results.rows[0].bucket;
  
		// Call the function and pass the values
		processDbCredentials(org_username, org_password,org_measurement,org_bucket,org_url,org_token,org_name);
	  });
	
	  function processDbCredentials(org_username, org_password,org_measurement,org_bucket,org_url,org_token,org_name) {
	  console.log(org_username,org_password,org_url)
	
	  { var influx = new InfluxDB({
		  url:org_url, 
		  token:org_token
	  })
	  var org = org_name
	  var start_limit=req.query.Start_Limit
	  if (!start_limit) {
		  var start=req.query.start
		  if (start) {
			  var start=req.query.start
			  const start_timestamp = new Date(start);
			  const start_timestamp1 = start_timestamp.getTime();
			  var StartTime1 = new Date((start_timestamp1-ZoneInfo)).toISOString().slice(0, 19);
			  var StartTime = StartTime1 + 'Z';
		  }
  
		  var stop=req.query.stop
		  if (stop) {	
			  const stop_timestamp = new Date(stop);
			  const stop_timestamp1 = stop_timestamp.getTime();
			  var StopTime1 = new Date((stop_timestamp1-ZoneInfo)).toISOString().slice(0, 19);
			  var StopTime = StopTime1 + 'Z';
			  console.log("stop time is update");
		  }
	  }
	  const queryApi = influx.getQueryApi(org)

	  if (start_limit) {
		fluxQuery = `from(bucket:"${org_bucket}") |> range(start: ${start_limit}) |> filter(fn: (r) => r["_measurement"] == "${org_measurement}")|> filter(fn: (r) => r["iid"] == "${iid}")|> filter(fn: (r) => r["bd"] == "${bd}")|> filter(fn: (r) => r["b"] == "${b}")|> filter(fn: (r) => r["d"] == "${d}")|> filter(fn: (r) => r["f"] == "${f}")|> filter(fn: (r) => r["_field"] == "value")  |> yield(name: "last")`;
	  } else {
		fluxQuery = `from(bucket:"${org_bucket}") |> range(start: ${StartTime}, stop: ${StopTime}) |> filter(fn: (r) => r["_measurement"] == "${org_measurement}")|> filter(fn: (r) => r["p"] == "${p}")|> filter(fn: (r) => r["iid"] == "${iid}")|> filter(fn: (r) => r["d"] == "${d}")|> filter(fn: (r) => r["f"] == "${f}")|> filter(fn: (r) => r["_field"] == "value")   |> aggregateWindow(every: 24h, offset:480m, fn: last, createEmpty: true)`;
	  }
	
	  console.log(new Date(),fluxQuery);
  
	  queryApi.queryRows(fluxQuery,{ next(row, tableMeta) {
		  o = tableMeta.toObject(row);
		  const date = new Date(o._time);
		  const timestamp = date.getTime();
		  var s = new Date(timestamp + ZoneInfo).toISOString();
		  //array.push(Array(`time:${s},id:${o.iid},b:${o.b},d:${o.d},f:${o.f},value:${o._value}`))
  
		  array.push(Array(s,o._value))
  
	  },
	  error(error) {
		  console.log('QUERY FAILED', error)
	  },
	  complete: () => {
		  const final = {
			  name: org_measurement,
			  tags: { f: f },
			  columns: ["time", "round"],
			  values: array
		  };
		  result.push(final);
		  res.send(result);
		  console.log('QUERY SUCCESS');
	  }
   })
  }
	  
  }});

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
// Start the server
app.listen(6600, () => {
  console.log('Server started on port 6600');
});

